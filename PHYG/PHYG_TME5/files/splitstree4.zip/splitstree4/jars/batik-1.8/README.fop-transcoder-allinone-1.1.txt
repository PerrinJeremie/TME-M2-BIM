The fop-transcoder-allinone-1.1.jar file is built from the Apache FOP project
(http://xmlgraphics.apache.org/fop), version 1.1.

This is only needed if you want to transcode to PDF, otherwise it can
be removed.

The pdf-transcoder.jar file is licensed under the Apache License 2.0, which
can be found in the distribution root directory in the LICENSE file.
